ARCHIVED
********

This was a shim for older versions of Python lacking enum support. It is no longer maintained. Feel free to take anything of value

EEnum
*****

EEnum is an extension to the python enum library.  It adds some features to
enum and wraps Enum3.4 so it can be used invisibly across python versions.

Installation
============

.. code-block:: bash

    $ pip install eenum

Supports
========

Python eenum has been tested with Python 2.7, 3.5, and 3.6
