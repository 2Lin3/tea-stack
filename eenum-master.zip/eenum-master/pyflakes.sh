#!/bin/bash

echo "============================================================"
echo "== pyflakes =="
pyflakes eenum.py unittests
