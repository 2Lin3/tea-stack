0.10
====

* project was initially part of http://python-wrench.readthedocs.io/en/latest/
* initial pypi commit of indendent library
